#Product of array except self
arr = [1, 2, 3, 4]
n = len(arr)

result = [1] * n

# Left pass
left = 1
for i in range(n):
    result[i] = left
    left *= arr[i]

# Right pass
right = 1
for i in range(n-1, -1, -1):
    result[i] *= right
    right *= arr[i]

print(result)
