T = int(input())

for x in range(T):
    N, K = map(int, input().split())
    arr = list(map(int, input().split()))

    K = K % N   # Important optimization

    rotated = arr[-K:] + arr[:-K]

    print(*rotated)

code3] toggle string
S = input()
print(S.swapcase())
