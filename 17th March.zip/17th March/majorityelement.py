#Find the majority element:
#Question : Find the majority element (element that appears motre than n/2 times)  in an array.
#sample input : [3,3,4,2,4,4,2,4,4]
#Expected output : Majority Element : 4  
arr = [3,3,4,2,4,4,2,4,4]

n = len(arr)

for i in arr:
    if arr.count(i) > n // 2:
        print("Majority Element :", i)
        break

