a = int(input("Enter any value: "))
b = int(input("Enter any valueb: "))
res = a+b
print(res)