no = int(input("Enter a 9 digit number: "))

n1 = no % 10          # last digit
n2 = no // 100000000  # first digit

res = n1 + n2

print("Sum =", res)
