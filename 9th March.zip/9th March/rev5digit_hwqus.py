no = int(input("Enter a 5 digit number: "))

rev = 0

while no > 0:
    rem = no % 10
    rev = rev * 10 + rem
    no = no // 10

print("Reversed number =", rev)
