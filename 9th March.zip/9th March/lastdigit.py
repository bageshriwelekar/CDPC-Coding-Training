n=int(input("Enter any value: "))
res=n%10
print(res)