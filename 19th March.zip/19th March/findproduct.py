MOD = 10**9 + 7

n = int(input())
arr = list(map(int, input().split()))

product = 1

for num in arr:
    product = (product * num) % MOD

print(product)
