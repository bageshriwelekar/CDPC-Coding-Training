
def find_max_min(arr):
    maximum = arr[0]
    minimum = arr[0]

    for i in arr:
        if i > maximum:
            maximum = i
        if i < minimum:
            minimum = i

    return maximum, minimum


# Input from user
n = int(input("Enter number of elements: "))
arr = []

for i in range(n):
    num = int(input("Enter element: "))
    arr.append(num)

max_val, min_val = find_max_min(arr)

print("Maximum element:", max_val)
print("Minimum element:", min_val)

code2] Solve me first

def solveMeFirst(a,b):
	return a+b 


num1 = int(input())
num2 = int(input())
res = solveMeFirst(num1,num2)
print(res)
