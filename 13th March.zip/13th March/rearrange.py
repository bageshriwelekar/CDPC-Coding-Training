def rearrange(arr):
    pos = []
    neg = []

    # separate positive and negative numbers
    for i in arr:
        if i >= 0:
            pos.append(i)
        else:
            neg.append(i)

    result = []
    i = j = 0

    # arrange alternately
    while i < len(pos) and j < len(neg):
        result.append(pos[i])
        result.append(neg[j])
        i += 1
        j += 1

    # add remaining elements
    while i < len(pos):
        result.append(pos[i])
        i += 1

    while j < len(neg):
        result.append(neg[j])
        j += 1

    return result


# input
n = int(input("Enter number of elements: "))
arr = list(map(int, input("Enter elements: ").split()))

res = rearrange(arr)
print("Rearranged array:", res)