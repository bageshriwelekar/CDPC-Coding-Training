#Question: Rotate an array to the right by a given number of steps
#sample input: [1,2,3,4,5] rotated by 2 steps 
#expected out: [4,5,1,2,3]
def rotate_right(arr, k):
    n = len(arr)
    k = k % n
    return arr[-k:] + arr[:-k]

arr = [1,2,3,4,5]
k = 2

result = rotate_right(arr, k)
print(result)
