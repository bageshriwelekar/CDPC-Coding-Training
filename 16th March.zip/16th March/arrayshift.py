n = int(input("Enter the number of Elements: "))
arr = []
for i in range(n):
    a = int(input("Enter the number: "))
    arr.append(a)
b = int(input("Enter the number of steps: "))
for _ in range(b):
    last_element = arr[n-1]
    for i in range(n-1, 0, -1):
        arr[i] = arr[i-1]
    arr[0] = last_element
for i in range(n):
    print(arr[i])
